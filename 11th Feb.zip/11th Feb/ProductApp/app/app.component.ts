import { Component } from '@angular/core';

@Component({
    selector: 'pm-app',
    template: `
        <h1>{{title}}</h1>
    `
})
export class AppComponent {

    title : string = "Hello Angular";

 }
